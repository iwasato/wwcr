GLYPHISH for iOS 11 - 200 Great icons, updated for iOS 11
(revision 1.1, 25 July 2016)
Created by Joseph Wain
Web: http://www.glyphish.com or http://www.penandthink.com
Twitter: @glyphish or @jpwain

----------

Thanks for supporting Glyphish!

LICENSE:

You're free to use these icons for commercial and non-commercial purposes, for yourself, your company and your clients, and to edit, remix and otherwise modify them without attribution.

You may not sell or redistribute the icons themselves as icons.

You may not use the icons in a way that encourages downstream distribution. This means no templates or skins or theme kits or similar uses. (The person using the theme or template might not know where the icons came from and thus wouldn't be following the license.)

The icons may not be used in any form of "easy app builder" tools or websites.

The icons may not be redistributed under any other license without expressed written permission.

Yes! Tattoo them on your arm, use them on your business cards. Do not resell them as icons or use them in app builder tools or templates.

REFUND POLICY:

Since these are digital files, no refunds or exchanges will be granted after completed sale. Additional downloads available upon request up to 60 days after purchase.

ATTRIBUTION:

None required for use by you, your company, your clients. But if you'd like to spread the word by linking to Glyphish from your website, blogpost, Twitter or wherever, your kind words are much appreciated.

QUESTIONS, COMMENTS, HELP:

Send a message via http://www.glyphish.com.

Follow @glyphish on Twitter for updates and more.